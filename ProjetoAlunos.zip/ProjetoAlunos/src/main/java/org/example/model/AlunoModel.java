package org.example.model;

// Representa a entidade Aluno
public class AlunoModel {

    private int codigo;
    private String nome;
    private String cpf;
    private int fase;

    // Getters e setters
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public int getFase() { return fase; }
    public void setFase(int fase) { this.fase = fase; }

    @Override
    public String toString() {
        return "Aluno{" +
                "codigo=" + codigo +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", fase=" + fase +
                '}';
    }
}