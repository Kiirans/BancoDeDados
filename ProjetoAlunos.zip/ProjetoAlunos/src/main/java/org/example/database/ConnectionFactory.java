package org.example.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Classe responsável pela conexão com o banco
public class ConnectionFactory {

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Conecta em uma database específica
    public static Connection getConnection(String database) {
        try {
            return DriverManager.getConnection(URL + database, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao conectar", e);
        }
    }

    // Conecta apenas no servidor (usado para criar database)
    public static Connection getConnectionServer() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao conectar no servidor", e);
        }
    }
}