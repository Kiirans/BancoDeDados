package org.example;

import org.example.dao.AlunoDao;
import org.example.model.AlunoModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws SQLException {

        Scanner sc = new Scanner(System.in);
        AlunoDao dao = null;

        while (true) {

            System.out.println("\n===== MENU =====");
            System.out.println("1 - Conexão ao Servidor MySQL");
            System.out.println("2 - Criar Database");
            System.out.println("3 - Conectar Database");
            System.out.println("4 - Criar Tabela");
            System.out.println("5 - Inserir Aluno");
            System.out.println("6 - Buscar por CPF");
            System.out.println("7 - Deletar por CPF");
            System.out.println("8 - Alterar Fase");
            System.out.println("0 - Sair");

            int opcao = sc.nextInt();
            sc.nextLine(); // limpa buffer

            switch (opcao) {

                case 1:
                    try {
                        Connection conn = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/",
                                "root",
                                ""
                        );
                        System.out.println("Conexão com servidor realizada com sucesso!");
                        conn.close();
                    } catch (SQLException e) {
                        System.out.println("Erro na conexão: " + e.getMessage());
                    }
                    break;

                case 2:
                    System.out.print("Nome da database: ");
                    AlunoDao.createDatabase(sc.nextLine());
                    break;

                case 3:
                    System.out.print("Nome da database: ");
                    dao = new AlunoDao(sc.nextLine());
                    System.out.println("Conectado à database.");
                    break;

                case 4:
                    dao.createTable();
                    break;

                case 5:
                    AlunoModel aluno = new AlunoModel();

                    System.out.print("Nome: ");
                    aluno.setNome(sc.nextLine());

                    System.out.print("CPF: ");
                    aluno.setCpf(sc.nextLine());

                    System.out.print("Fase: ");
                    aluno.setFase(sc.nextInt());

                    dao.insert(aluno);
                    break;

                case 6:
                    System.out.print("CPF: ");
                    System.out.println(dao.buscarPorCpf(sc.nextLine()));
                    break;

                case 7:
                    System.out.print("CPF: ");
                    dao.deleteByCpf(sc.nextLine());
                    break;

                case 8:
                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();

                    System.out.print("Nova fase: ");
                    int fase = sc.nextInt();

                    dao.updateFase(cpf, fase);
                    break;

                case 0:
                    System.exit(0);
            }
        }
    }
}