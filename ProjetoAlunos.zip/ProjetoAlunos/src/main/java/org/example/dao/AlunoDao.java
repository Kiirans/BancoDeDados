package org.example.dao;

import org.example.database.ConnectionFactory;
import org.example.model.AlunoModel;

import java.sql.*;

public class AlunoDao {

    private Connection connection;

    // Conecta no banco ao criar o DAO
    public AlunoDao(String database) {
        this.connection = ConnectionFactory.getConnection(database);
    }

    public static void createDatabase(String nome) throws SQLException {
        Connection conn = ConnectionFactory.getConnectionServer();
        Statement stmt = conn.createStatement();
        stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + nome);
        System.out.println("Database criada.");
    }

    public void createTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS alunos(" +
                "codigo INT AUTO_INCREMENT PRIMARY KEY," +
                "nome VARCHAR(100)," +
                "cpf VARCHAR(14)," +
                "fase INT)";

        Statement stmt = connection.createStatement();
        stmt.executeUpdate(sql);

        System.out.println("Tabela criada.");
    }

    // INSERT
    public void insert(AlunoModel aluno) throws SQLException {

        String sql = "INSERT INTO alunos(nome, cpf, fase) VALUES (?, ?, ?)";

        // Uso de PreparedStatement para evitar problemas com SQL
        PreparedStatement stmt = connection.prepareStatement(sql);

        stmt.setString(1, aluno.getNome());
        stmt.setString(2, aluno.getCpf());
        stmt.setInt(3, aluno.getFase());

        stmt.executeUpdate();
        System.out.println("Aluno inserido.");
    }

    // SELECT por CPF
    public AlunoModel buscarPorCpf(String cpf) throws SQLException {

        String sql = "SELECT * FROM alunos WHERE cpf = ?";

        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, cpf);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            AlunoModel aluno = new AlunoModel();
            aluno.setCodigo(rs.getInt("codigo"));
            aluno.setNome(rs.getString("nome"));
            aluno.setCpf(rs.getString("cpf"));
            aluno.setFase(rs.getInt("fase"));
            return aluno;
        }

        return null;
    }

    // DELETE por CPF
    public void deleteByCpf(String cpf) throws SQLException {

        String sql = "DELETE FROM alunos WHERE cpf = ?";

        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, cpf);

        stmt.executeUpdate();
        System.out.println("Aluno removido.");
    }

    // UPDATE fase
    public void updateFase(String cpf, int novaFase) throws SQLException {

        AlunoModel antes = buscarPorCpf(cpf);

        if (antes == null) {
            System.out.println("Aluno não encontrado.");
            return;
        }

        System.out.println("Antes: " + antes);

        String sql = "UPDATE alunos SET fase = ? WHERE cpf = ?";

        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setInt(1, novaFase);
        stmt.setString(2, cpf);

        stmt.executeUpdate();

        AlunoModel depois = buscarPorCpf(cpf);
        System.out.println("Depois: " + depois);
    }
}