package org.example.dao;

import org.example.model.AlunoModel;

import java.util.List;

public interface DaoInterface {

    public List <AlunoModel> getAll();
    public void insert (AlunoModel usuario);
    public void update (AlunoModel usuario);
    public void delete (AlunoModel usuario);
}
